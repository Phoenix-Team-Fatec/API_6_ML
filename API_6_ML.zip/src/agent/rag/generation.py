from langchain_ollama import ChatOllama
from src.agent.rag.retriever import Retriever
from src.agent.config.settings import settings
from src.agent.rag.vector_store import VectorStore

class CodeRAG:
    def __init__(self):
        self.storge = VectorStore()
        self.retriver = Retriever()
        self.llm = ChatOllama(
         model =settings.llm_model,
         temperature=0,
        )
    
    def answer(self, query: str) -> str:
        context = self.retriver.get_context(query)

        system_prompt = """
        Você é um gerador de código.
        Responda somente com código puro.
        Não explique.
        Não use markdown.
        Não use blocos ``` .
        Não escreva texto antes ou depois do código.
        Se a tarefa estiver ambígua, assuma a implementação mais simples e segura.
        Se precisar de múltiplos arquivos, concatene o conteúdo em um único arquivo executável.
        """

        user_prompt = f"""
        Contexto:
        {context}

        Tarefa:
        {query}
        """

        response = self.llm.invoke([
            ("system", system_prompt),
            ("human", user_prompt)
        ])

        return response.content