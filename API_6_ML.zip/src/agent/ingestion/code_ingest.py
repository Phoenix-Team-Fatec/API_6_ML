from pathlib import Path
from langchain_text_splitters import RecursiveCharacterTextSplitter


def load_codebase(root_path: str, extensions: tuple[str, ...] = (".py",)) -> list[dict]:
    root = Path(root_path)

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800,
        chunk_overlap=120,
        separators=["\nclass ", "\ndef ", "\n\n", "\n", " ", ""],
    )

    chunks: list[dict] = []

    for file_path in root.rglob("*"):
        if not file_path.is_file():
            continue

        if file_path.suffix not in extensions:
            continue

        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception:
            continue

        if not content.strip():
            continue

        split_texts = splitter.split_text(content)

        for i, chunk in enumerate(split_texts):
            if not chunk.strip():
                continue

            chunks.append(
                {
                    "text": chunk,
                    "file_path": str(file_path),
                    "chunk_id": i,
                    "language": file_path.suffix.lstrip("."),
                }
            )

    return chunks